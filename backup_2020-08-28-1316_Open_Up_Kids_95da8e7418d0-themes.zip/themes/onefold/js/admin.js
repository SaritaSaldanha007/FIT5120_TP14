( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#onefold-settings-metabox-container' ).tabs();

	});

} )( jQuery );
