jQuery(document).ready(function($){
	
    $('.page_header_bg_color').wpColorPicker();
	
	
});